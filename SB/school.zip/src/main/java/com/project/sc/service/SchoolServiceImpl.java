package com.project.sc.service;

import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.project.sc.dao.SchoolDAO;
import com.project.sc.vo.SchoolVO;

@Service("SchoolService")
@Transactional(propagation = Propagation.REQUIRED)
public class SchoolServiceImpl implements SchoolService {
    @Autowired
    private SchoolDAO schoolDAO;
    
    @Override
    public List listst() throws Exception {
        List stList = null;
        stList = schoolDAO.StudentList();
        return stList;
    }
    
    @Override
    public SchoolVO InfoStudent(String stNo) throws Exception {
        return schoolDAO.InfoStudent(stNo);
    }
    
	@Override
	public int addStudent(SchoolVO school) throws Exception {
		 return schoolDAO.InsertStudent(school);
	}
	
	@Override
	public void UpdateStudent(SchoolVO student) throws Exception {
		schoolDAO.UpdateStudent(student);
	}
		
	@Override
	public void DeleteStudent(String stNo) throws Exception {
		schoolDAO.DeleteStudent(stNo);
	}
	
	@Override
	public List listGrade(String stNo) throws Exception {
	    List listGrade = null;
	    listGrade = schoolDAO.StudentGrade(stNo);
	    return listGrade;
	}
	
	@Override
	public List<SchoolVO> getAttendance(String st_name, String st_no, Date startDate, Date endDate) throws Exception {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("st_name", st_name);
		paramMap.put("st_no", st_no);
		paramMap.put("startDate", startDate);
		paramMap.put("endDate", endDate);

		return schoolDAO.selectAttendance(paramMap);
	}
	
	// 출결 상태 업데이트 메서드
	@Override
	public void updateAttendance(String attendanceNo, String newStatus, String st_no, String startDate, String endDate)
			throws Exception {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("attendanceNo", attendanceNo);
		paramMap.put("newStatus", newStatus);
		paramMap.put("st_no", st_no);
		paramMap.put("startDate", startDate);
		paramMap.put("endDate", endDate);
		schoolDAO.updateAttendance(paramMap);
	}

}