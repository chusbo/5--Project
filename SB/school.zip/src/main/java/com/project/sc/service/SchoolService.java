package com.project.sc.service;

import java.sql.Date;
import java.util.List;

import com.project.sc.vo.SchoolVO;

public interface SchoolService {
    public List listst() throws Exception;
    public SchoolVO InfoStudent(String stNo) throws Exception;
    public int addStudent(SchoolVO schoolVO) throws Exception;
    public void DeleteStudent(String stNo) throws Exception;
    public void UpdateStudent(SchoolVO student) throws Exception;
    public List listGrade(String stNo) throws Exception;
    public List<SchoolVO> getAttendance(String st_name, String st_no, Date startDate, Date endDate) throws Exception;
    public void updateAttendance(String attendanceNo, String newStatus, String st_no, String startDate, String endDate) throws Exception;
 }