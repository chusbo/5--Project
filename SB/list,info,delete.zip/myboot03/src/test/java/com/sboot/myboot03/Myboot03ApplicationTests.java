package com.sboot.myboot03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Myboot03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
