package com.project.sc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.project.sc.service.SchoolService;
import com.project.sc.vo.SchoolVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller("SchoolController")
public class SchoolControllerImpl implements SchoolController {
    
    @Autowired
    private SchoolService schoolService;
    
    @Override
    @GetMapping("/stList.do")
    public ModelAndView listst(HttpServletRequest request, HttpServletResponse response) throws Exception {
        List stList = schoolService.listst();
        ModelAndView mav = new ModelAndView("stList");
        mav.addObject("stList", stList);
        return mav;
    }
    
    @Override
    @GetMapping("/stInfo.do")
    public ModelAndView stInfo(HttpServletRequest request, HttpServletResponse response, @RequestParam("stNo") String stNo) throws Exception {
        SchoolVO student = schoolService.InfoStudent(stNo);
        ModelAndView mav = new ModelAndView("stInfo");
        mav.addObject("student", student);
        return mav;
    }         

    @Override
    @PostMapping("/stAdd.do")
    public ModelAndView addStudent(@ModelAttribute("school") SchoolVO school,
            HttpServletRequest request, HttpServletResponse response) throws Exception {
        request.setCharacterEncoding("utf-8");
        int result = schoolService.addStudent(school);
        ModelAndView mav = new ModelAndView("redirect:/stList.do");
        return mav;
    }
    
    @Override
    @GetMapping("/stAddForm.do")
    public ModelAndView newStudentForm(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ModelAndView mav = new ModelAndView("stAdd");
        return mav;
    }
    
    @Override
    @GetMapping("/stMod.do")
    public ModelAndView modStudentForm(@RequestParam("stNo") String stNo, HttpServletRequest request, HttpServletResponse response) throws Exception {
        SchoolVO student = schoolService.InfoStudent(stNo);
        ModelAndView mav = new ModelAndView("/stMod");
        mav.addObject("student", student);
        return mav;
    }

    @PostMapping("/updateStudent.do")
    public ModelAndView modMember(@ModelAttribute("student") SchoolVO student, HttpServletRequest request, HttpServletResponse response) throws Exception {
        schoolService.UpdateStudent(student);
        ModelAndView mav = new ModelAndView("redirect:/stList.do");
        return mav;
    }
    
    @Override
    @GetMapping("/DeleteStudent.do")
    public ModelAndView DeleteStudent(@RequestParam("stNo") String stNo, HttpServletRequest request, HttpServletResponse response) throws Exception {
        schoolService.DeleteStudent(stNo);
        ModelAndView mav = new ModelAndView("redirect:/stList.do");
        return mav;
    }
    
    @Override
    @GetMapping("/stGrade.do")
    public ModelAndView listGrade(@RequestParam("stNo") String stNo, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List listGrade = schoolService.listGrade(stNo);
        ModelAndView mav = new ModelAndView("stGrade");
        mav.addObject("listGrade", listGrade);
        return mav;
    }
}