package com.project.sc.controller;

import org.springframework.stereotype.Controller;

@Controller("SchoolController")
public class SchoolControllerImpl implements SchoolController {
    
   
}
