package com.project.sc.controller;

public interface SchoolController {
}