package com.project.sc.dao;

public class SchoolDAO {

}
