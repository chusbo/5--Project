package com.project.sc.service;

public class SchoolServiceImpl {

}
