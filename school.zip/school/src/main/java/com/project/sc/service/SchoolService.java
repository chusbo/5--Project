package com.project.sc.service;

public class SchoolService {

}
