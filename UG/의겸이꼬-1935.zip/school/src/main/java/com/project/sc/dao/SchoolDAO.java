package com.project.sc.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.project.sc.vo.SchoolVO;

@Mapper
@Repository("SchoolDAO")
public interface SchoolDAO {
//	public List<SchoolVO> StudentList() throws DataAccessException;
    public SchoolVO getStudentByNo(String stNo) throws DataAccessException;
//	public List<SchoolVO> TeacherList() throws DataAccessException;
    public SchoolVO getTeacherByNo(String tcNo) throws DataAccessException;
    public List<SchoolVO> findByTcNo(String tcNo) throws DataAccessException;
    public SchoolVO findTcNameByTcNo(String tcNo) throws DataAccessException;
    public List<SchoolVO> subjectGrades(String tcNo) throws DataAccessException;
    public void insertSubjectGrades(SchoolVO schoolVO) throws DataAccessException;
    public void insertSubjectGradesProcess(SchoolVO schoolVO) throws DataAccessException;
    public void updateSubjectGrades(SchoolVO schoolVO) throws DataAccessException;
	
    
    public void attendeceUpdate(String endDate);
	public List<SchoolVO> AttendanceAll() throws DataAccessException;
	public void updateAttendance(Map<String, Object> paramMap) throws DataAccessException;
}