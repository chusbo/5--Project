package com.project.sc.controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.project.sc.service.SchoolService;
import com.project.sc.vo.SchoolVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller("SchoolController")
public class SchoolControllerImpl implements SchoolController {
    
    @Autowired
    private SchoolService schoolService;
    
    // 학생 목록 조회
//    @Override
//    @GetMapping("/stList.do")
//    public ModelAndView stList(HttpServletRequest request, HttpServletResponse response) throws Exception {
//        List<SchoolVO> stList = schoolService.stList();
//        ModelAndView mav = new ModelAndView("stList");
//        mav.addObject("stList", stList);
//        return mav;
//    }
    
    // 학생 상세 정보 조회
    @Override
    @GetMapping("/stInfo.do")
    public ModelAndView stInfo(HttpServletRequest request, HttpServletResponse response, @RequestParam("stNo") String stNo) throws Exception {
        SchoolVO student = schoolService.getStudentByNo(stNo);
        ModelAndView mav = new ModelAndView("stInfo");
        mav.addObject("student", student);
        return mav;
    }
    
    // 선생 목록 조회
//    @Override
//    @GetMapping("/tcList.do")
//    public ModelAndView tcList(HttpServletRequest request, HttpServletResponse response) throws Exception {
//        List<SchoolVO> tcList = schoolService.tcList();
//        ModelAndView mav = new ModelAndView("tcList");
//        mav.addObject("tcList", tcList);
//        return mav;
//    }
    
    // 선생 상세 정보 조회
    @Override
    @GetMapping("/tcInfo.do")
    public ModelAndView tcInfo(HttpServletRequest request, HttpServletResponse response, @RequestParam("tcNo") String tcNo) throws Exception {
        SchoolVO teacher = schoolService.getTeacherByNo(tcNo);
        ModelAndView mav = new ModelAndView("tcInfo");
        mav.addObject("teacher", teacher);
        return mav;
    }
	
    // 선생 번호로 담임 학급 학생 조회(입력 폼)
    @GetMapping("/findByTcNo.do")
    public ModelAndView findByTcNoForm() {
        ModelAndView mav = new ModelAndView("findByTcNo");
        return mav;
    }
    
    // 선생 번호로 담임 학급 학생 조회
	@Override
	@PostMapping("/findByTcNo.do")
	public ModelAndView findByTcNo(HttpServletRequest request, HttpServletResponse response, @RequestParam("tcNo") String tcNo) throws Exception {
		List<SchoolVO> findByTcNo = schoolService.findByTcNo(tcNo);
		SchoolVO tcName = schoolService.findTcNameByTcNo(tcNo);
		ModelAndView mav = new ModelAndView("findByTcNo");
		mav.addObject("findByTcNo", findByTcNo);
		mav.addObject("tcNo", tcNo);
		mav.addObject("tcName", tcName);
		return mav;
	}
	
	// 선생 번호로 담당 과목 성적 조회
	@Override
	@GetMapping("/subjectGrades.do")
	public ModelAndView subjectGrades(HttpServletRequest request, HttpServletResponse response, @RequestParam("tcNo") String tcNo) throws Exception {
		List<SchoolVO> subjectGrades = schoolService.subjectGrades(tcNo);
		SchoolVO tcName = schoolService.findTcNameByTcNo(tcNo);
		ModelAndView mav = new ModelAndView("subjectGrades");
		mav.addObject("subjectGrades", subjectGrades);
		mav.addObject("tcName", tcName);
		return mav;
	}
	
	// 담당 과목 성적 입력(입력 폼)
	@Override
	@GetMapping("/insertSubjectGrades.do")
	public ModelAndView insertSubjectGrades(HttpServletRequest request, HttpServletResponse response, SchoolVO schoolVO) throws Exception {
		ModelAndView mav = new ModelAndView("insertSubjectGrades");
		return mav;
	}
	
	// 담당 과목 성적 입력(처리 프로세스)
	@Override
	@PostMapping("/insertSubjectGradesProcess.do")
	public ModelAndView insertSubjectGradesProcess(HttpServletRequest request, HttpServletResponse response, SchoolVO schoolVO) throws Exception {
	    schoolService.insertSubjectGradesProcess(schoolVO);
	    ModelAndView mav = new ModelAndView("redirect:/subjectGradesByTcNo.do?tcNo=" + schoolVO.getTc_no());
	    return mav;
	}
	
	// 담당 과목 성적 수정(폼)
	@GetMapping("/modSubjectGrades.do")
	public ModelAndView modSubjectGradesForm(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView("updateSubjectGrades");
		return mav;
	}
	
	// 담당 과목 성적 수정(폼)
	@Override
	@PostMapping("/modSubjectGrades.do")
	public ModelAndView modSubjectGrades(@ModelAttribute("schoolVO") SchoolVO schoolVO, HttpServletRequest request, HttpServletResponse response) throws Exception {
		schoolService.updateSubjectGrades(schoolVO);
		ModelAndView mav = new ModelAndView("updateSubjectGrades");
		return mav;
	}

	// 담당 과목 성적 수정(처리)
	@Override
	@PostMapping("/updateSubjectGrades.do")
	public ModelAndView updateSubjectGrades(@ModelAttribute("schoolVO") SchoolVO schoolVO, HttpServletRequest request, HttpServletResponse response) throws Exception {
		schoolService.updateSubjectGrades(schoolVO);
		ModelAndView mav = new ModelAndView("redirect:/modSubjectGrades.do"); 
		return mav;
	}
	
	



	
    @PostMapping("/attendeceUpdate.do")
    public ModelAndView attendeceUpdate(HttpServletRequest request, HttpServletResponse response,
                                         @RequestParam("endDate") String endDate) throws Exception {
        schoolService.attendeceUpdate(endDate);
        ModelAndView mav = new ModelAndView("redirect:/aaa.do");
        return mav;
    }
    
    @Override
    @GetMapping("/aaa.do")
    public ModelAndView AttendanceAll(HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<SchoolVO> AttendanceAll  = schoolService.AttendanceAll();
        ModelAndView mav = new ModelAndView("aaa");
        mav.addObject("AttendanceAll", AttendanceAll);
        return mav;
    }
    
	@Override
	@PostMapping("/updateAttendance.do")
	public ModelAndView updateAttendance(@RequestParam("attendanceNo") String attendanceNo,
			@RequestParam("newStatus") String newStatus, @RequestParam("st_no") String stNoStr,
			@RequestParam("startDate") String startDateStr, @RequestParam("endDate") String endDateStr)
			throws Exception {
		schoolService.updateAttendance(attendanceNo, newStatus, stNoStr, startDateStr, endDateStr);

		return new ModelAndView("redirect:/aaa.do");
	}
}