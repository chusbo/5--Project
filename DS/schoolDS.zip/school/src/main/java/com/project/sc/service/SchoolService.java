package com.project.sc.service;

import java.util.List;

import com.project.sc.vo.SchoolVO;

public interface SchoolService {
	public List<SchoolVO> stList() throws Exception;							// 학생 목록
    public SchoolVO getStudentByNo(String stNo) throws Exception;				// 학생 번호로 학생 정보 조회
    public List<SchoolVO> tcList() throws Exception;							// 선생 목록
    public SchoolVO getTeacherByNo(String tcNo) throws Exception;				// 선생 번호로 선생 정보 조회
    public List<SchoolVO> findByTcNo(String tcNo) throws Exception; 			// 선생 번호로 담당 학생번호, 학생명 조회
    public SchoolVO findTcNameByTcNo(String tcNo) throws Exception;				// 선생 번호로 선생명 조회
    public List<SchoolVO> subjectGradesByTcNo(String tcNo) throws Exception;	// 선생 번호로 담당 과목 성적 조회
    public void insertSubjectGrades(SchoolVO schoolVO) throws Exception;    		// 선생 번호로 담당 과목 성적 입력
    public void insertSubjectGradesProcess(SchoolVO schoolVO) throws Exception;	// 선생 번호로 담당 과목 성적 입력(처리)
}