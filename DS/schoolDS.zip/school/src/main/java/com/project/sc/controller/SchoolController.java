package com.project.sc.controller;

import org.springframework.web.servlet.ModelAndView;

import com.project.sc.vo.SchoolVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface SchoolController {
	public ModelAndView stList(HttpServletRequest request, HttpServletResponse response) throws Exception;
    public ModelAndView stInfo(HttpServletRequest request, HttpServletResponse response, String stNo) throws Exception;
	public ModelAndView tcList(HttpServletRequest request, HttpServletResponse response) throws Exception;
    public ModelAndView tcInfo(HttpServletRequest request, HttpServletResponse response, String tcNo) throws Exception;
    public ModelAndView findByTcNo(HttpServletRequest request, HttpServletResponse response, String tcNo) throws Exception;
    public ModelAndView subjectGradesByTcNo(HttpServletRequest request, HttpServletResponse response, String tcNo) throws Exception;
    public ModelAndView insertSubjectGrades(HttpServletRequest request, HttpServletResponse response, SchoolVO schoolVO) throws Exception;
    public ModelAndView insertSubjectGradesProcess(HttpServletRequest request, HttpServletResponse response, SchoolVO schoolVO) throws Exception;
}