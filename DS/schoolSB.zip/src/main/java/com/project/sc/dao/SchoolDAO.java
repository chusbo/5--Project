package com.project.sc.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.project.sc.vo.SchoolVO;

@Mapper
@Repository("SchoolDAO")
public interface SchoolDAO {
	public List<SchoolVO> StudentList() throws DataAccessException;
    public SchoolVO InfoStudent(String stNo) throws DataAccessException;
    public int InsertStudent(SchoolVO schoolVO) throws DataAccessException;
    public void UpdateStudent(SchoolVO student) throws DataAccessException;
    public void DeleteStudent(String stNo) throws DataAccessException;
    public List<SchoolVO> StudentGrade(String stNo) throws DataAccessException;
    public List<SchoolVO> selectAttendance(Map<String, Object> paramMap) throws DataAccessException;
}