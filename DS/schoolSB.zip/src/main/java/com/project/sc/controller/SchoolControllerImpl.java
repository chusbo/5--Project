package com.project.sc.controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.project.sc.service.SchoolService;
import com.project.sc.vo.SchoolVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller("SchoolController")
public class SchoolControllerImpl implements SchoolController {
    
    @Autowired
    private SchoolService schoolService;
    
    //학생정보 리스트
    @Override
    @GetMapping("/stList.do")
    public ModelAndView listst(HttpServletRequest request, HttpServletResponse response) throws Exception {
        List stList = schoolService.listst();
        ModelAndView mav = new ModelAndView("stList");
        mav.addObject("stList", stList);
        return mav;
    }
    
    //학생 상세 정보
    @Override
    @GetMapping("/stInfo.do")
    public ModelAndView stInfo(HttpServletRequest request, HttpServletResponse response, @RequestParam("stNo") String stNo) throws Exception {
        SchoolVO student = schoolService.InfoStudent(stNo);
        ModelAndView mav = new ModelAndView("stInfo");
        mav.addObject("student", student);
        return mav;
    }         

    //신규학생 등록
    @Override
    @PostMapping("/stAdd.do")
    public ModelAndView addStudent(@ModelAttribute("school") SchoolVO school,
            HttpServletRequest request, HttpServletResponse response) throws Exception {
        request.setCharacterEncoding("utf-8");
        int result = schoolService.addStudent(school);
        ModelAndView mav = new ModelAndView("redirect:/stList.do");
        return mav;
    }
    
    //신규학생 등록
    @Override
    @GetMapping("/stAddForm.do")
    public ModelAndView newStudentForm(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ModelAndView mav = new ModelAndView("stAdd");
        return mav;
    }
    
    //학생정보 수정
    @Override
    @GetMapping("/stMod.do")
    public ModelAndView modStudentForm(@RequestParam("stNo") String stNo, HttpServletRequest request, HttpServletResponse response) throws Exception {
        SchoolVO student = schoolService.InfoStudent(stNo);
        ModelAndView mav = new ModelAndView("/stMod");
        mav.addObject("student", student);
        return mav;
    }

    //학생정보 수정
    @PostMapping("/updateStudent.do")
    public ModelAndView modMember(@ModelAttribute("student") SchoolVO student, HttpServletRequest request, HttpServletResponse response) throws Exception {
        schoolService.UpdateStudent(student);
        ModelAndView mav = new ModelAndView("redirect:/stList.do");
        return mav;
    }
    
    //학생정보 삭제
    @Override
    @GetMapping("/DeleteStudent.do")
    public ModelAndView DeleteStudent(@RequestParam("stNo") String stNo, HttpServletRequest request, HttpServletResponse response) throws Exception {
        schoolService.DeleteStudent(stNo);
        ModelAndView mav = new ModelAndView("redirect:/stList.do");
        return mav;
    }
    
    //학생 성적조회
    @Override
    @GetMapping("/stGrade.do")
    public ModelAndView listGrade(@RequestParam("stNo") String stNo, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List listGrade = schoolService.listGrade(stNo);
        ModelAndView mav = new ModelAndView("stGrade");
        mav.addObject("listGrade", listGrade);
        return mav;
    }
    
 	@GetMapping("/attendanceForm.do")
 	public String attendanceForm() {
 		return "attendanceList";
 	}

 	@Override
	@GetMapping("/attendanceList.do")
	public ModelAndView searchAttendance(@RequestParam("st_no") String stNoStr,
			@RequestParam("startDate") String startDateStr, @RequestParam("endDate") String endDateStr)
			throws Exception {
		ModelAndView mav = new ModelAndView("attendanceList");

		String st_no = stNoStr;
		Date startDate = Date.valueOf(startDateStr);
		Date endDate = Date.valueOf(endDateStr);

		if (startDate.after(endDate)) {
			mav.addObject("errorMessage", "시작 날짜는 종료 날짜보다 이전이어야 합니다.");
			return mav;
		}

		List<SchoolVO> attendanceList = schoolService.getAttendance(st_no, startDate, endDate);

		mav.addObject("attendanceList", attendanceList);
		return mav;
	}
}